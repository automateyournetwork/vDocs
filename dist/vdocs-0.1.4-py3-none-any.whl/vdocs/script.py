from .vdocs import cli
def run():
    cli()